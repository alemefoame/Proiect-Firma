# Cerinte suplimentare
- PHP ce trimite mail-uri functional
- Demo functional la adresa vildenes.zaha.tech

# Observatii
- Proiectul este facut din nou in ultimul moment, deci este cam messy :))