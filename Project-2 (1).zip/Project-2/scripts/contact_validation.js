const form = document.getElementById("contactForm");

form.addEventListener("submit", function (ev) {
    const formValues = {
        name: document.getElementById("name").value,
        email: document.getElementById("emailId").value,
        subject: document.getElementById("subject").value,
        message: document.getElementById("msgContent").value
    }
    let errors = [];

    if (formValues.name.length < 3) {
        errors.push("Numele trebuie sa aiba cel putin 3 caractere");
    }

    // check if email is valid using regex
    const emailRegex = new RegExp('[a-z0-9]+@[a-z]+\.[a-z]{2,3}');
    if (!emailRegex.test(formValues.email)) {
        errors.push("Email-ul nu este valid");
    }

    if (formValues.subject.length < 5) {
        errors.push("Subiectul trebuie sa aiba cel putin 5 caractere");
    }

    if (formValues.message.length < 10) {
        errors.push("Mesajul trebuie sa aiba cel putin 10 caractere");
    }

    if (errors.length > 0) {
        ev.preventDefault();
        alert(errors.join("\n"));
    }
}, false);