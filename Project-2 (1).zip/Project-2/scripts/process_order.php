<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the order data from the request body
    $order = json_decode(file_get_contents('php://input'), true);

    // Extract the order details
    $name = $order['name'];
    $email = $order['email'];
    $phone = $order['phone'];
    $address = $order['address'];
    $deliveryDate = $order['deliveryDate'];
    $cart = $order['cart'];
    $details = $order['details'];

    // Format the order details into a message
    $message = "Detalii Comandă:\n\n";
    $message .= "Nume: $name\n";
    $message .= "Email: $email\n";
    $message .= "Telefon: $phone\n";
    $message .= "Adresă: $address\n";
    $message .= "Data livrare: $deliveryDate\n\n";
    $message .= "Observații: $details\n\n";
    $message .= "-------------------------\n\n";
    $message .= "Produse comandate:\n";

    foreach ($cart as $item) {
        $productId = $item['id'];
        $productName = $item['name'];
        $quantity = $item['quantity'];

        $message .= "ID Produs: $productId\n";
        $message .= "Nume Produs: $productName\n";
        $message .= "Cantitate: $quantity\n\n";
    }

    // Send the email
    $to = 'vildenes@zaha.tech';
    $subject = 'Comandă Nouă';
    $headers = "From: $email\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "Content-Type: text/plain; charset=utf-8\r\n";

    if (mail($to, $subject, $message, $headers)) {
        // Email sent successfully
        echo json_encode(['success' => true]);
    } else {
        // Error sending email
        echo json_encode(['success' => false, 'error' => 'Eroare la trimiterea email-ului.']);
    }
}
?>
