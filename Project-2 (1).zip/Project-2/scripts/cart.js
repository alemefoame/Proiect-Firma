document.addEventListener('DOMContentLoaded', function () {
    // Retrieve the cart data from local storage
    var cartData = localStorage.getItem('cart');
    var cart = cartData ? JSON.parse(cartData) : [];

    // Get the cart items container element
    var cartItemsContainer = document.getElementById('cart-items');

    // Iterate over the cart items
    cart.forEach(function (cartItem) {
        var product = cartItem.product;
        var quantity = cartItem.quantity;

        // Create the cart item element
        var cartItemElement = document.createElement('div');
        cartItemElement.classList.add('cart-item');

        // Create the product name element
        var productNameElement = document.createElement('h3');
        productNameElement.textContent = product.name;
        cartItemElement.appendChild(productNameElement);

        // Create the price element
        var priceElement = document.createElement('div');
        priceElement.classList.add('price');
        priceElement.textContent = product.price + ' LEI';
        cartItemElement.appendChild(priceElement);

        // Create the quantity selector element
        var quantitySelectorElement = document.createElement('select');
        quantitySelectorElement.name = 'quantity-' + product.id;

        // Populate the quantity selector with options
        for (var i = 0; i <= 100; i++) {
            var optionElement = document.createElement('option');
            optionElement.value = i;
            optionElement.textContent = i;
            if (i === quantity) {
                optionElement.selected = true;
            }
            quantitySelectorElement.appendChild(optionElement);
        }

        // Add event listener to update the quantity when selection changes
        quantitySelectorElement.addEventListener('change', function (event) {
            var newQuantity = parseInt(event.target.value);
            updateCartItemQuantity(product.id, newQuantity);
        });

        // Add the quantity selector to the cart item
        cartItemElement.appendChild(quantitySelectorElement);

        // Add the cart item to the container
        cartItemsContainer.appendChild(cartItemElement);
    });

    // Set the minimum value for the delivery date field as the current date
    var deliveryDateInput = document.getElementById('deliveryDate');
    deliveryDateInput.min = new Date().toISOString().split('T')[0];

});

// Function to update the quantity of a cart item in local storage
function updateCartItemQuantity(productId, newQuantity) {
    // Retrieve the cart data from local storage
    var cartData = localStorage.getItem('cart');
    var cart = cartData ? JSON.parse(cartData) : [];

    // Find the cart item based on the productId
    var cartItem = cart.find(function (item) {
        return item.productId === productId;
    });

    if (cartItem) {
        // If quantity is 0 remove the item
        if (newQuantity === 0) {
            var cartItemIndex = cart.indexOf(cartItem);
            cart.splice(cartItemIndex, 1);

            // reload the page
            location.reload();
        }

        // Update the quantity
        cartItem.quantity = newQuantity;

        // Update the cart data in local storage
        localStorage.setItem('cart', JSON.stringify(cart));
    }
}

const form = document.getElementById('checkout-form');

form.addEventListener('submit', function (event) {
    // Prevent the form from submitting
    event.preventDefault();

    // Retrieve the cart data from local storage
    var cartData = localStorage.getItem('cart');
    var cart = cartData ? JSON.parse(cartData) : [];

    // Create the order object
    var order = {
        name: form.name.value,
        email: form.emailId.value,
        phone: form.phone.value,
        address: form.address.value,
        details: form.details.value,
        deliveryDate: form.deliveryDate.value,
        cart: cart
    };

    // Validate the order
    var errors = [];

    if (order.name.length < 3) {
        errors.push('Numele trebuie sa aiba cel putin 3 caractere');
    }

    // check if email is valid using regex
    const emailRegex = new RegExp('[a-z0-9]+@[a-z]+\.[a-z]{2,3}');
    if (!emailRegex.test(order.email)) {
        errors.push('Email-ul nu este valid');
    }

    // check if phone is valid using regex
    const phoneRegex = new RegExp('[0-9]{10}');
    if (!phoneRegex.test(order.phone)) {
        errors.push('Numarul de telefon nu este valid');
    }

    if (order.address.length < 10) {
        errors.push('Adresa trebuie sa aiba cel putin 10 caractere');
    }

    if (order.deliveryDate === '') {
        errors.push('Va rugam sa selectati o data de livrare');
    }

    // check if the cart is empty
    if (cart.length === 0) {
        errors.push('Nu aveti produse in cos');
    }

    if (errors.length > 0) {
        alert(errors.join('\n'));
        return;
    }

    // Send the order to the server
    fetch('/scripts/process_order.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(order)
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            console.log('Order created:', data);
            alert('Comanda a fost plasata cu succes!');
            localStorage.removeItem('cart');
            window.location.href = 'index.html';
        });
});