// Function to fetch and insert the header HTML
function insertHeader() {
    fetch('../global/header.html')
        .then(response => response.text())
        .then(html => {
            document.getElementById('header').innerHTML = html;

            // Menu functionality
            let navbar = document.querySelector('.navbar');

            document.querySelector('#menu-btn').onclick = () => {
                navbar.classList.toggle('active');
            }

            window.onscroll = () => {
                navbar.classList.remove('active');
            }

        });
}

// Function to fetch and insert the footer HTML
function insertFooter() {
    fetch('/global/footer.html')
        .then(response => response.text())
        .then(html => {
            document.getElementById('footer').innerHTML = html;
        });
}

// Call the functions to insert the header and footer
insertHeader();
insertFooter();