<?php

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $mailFrom = $_POST['emailId'];
    $subject = $_POST['subject'];
    $message = $_POST['msgContent'];

    $mailTo = "vildenes@zaha.tech";
    $headers = "From: " . $mailFrom;
    $txt = $name . " a folosit formularul de contact: \n\n" . $message;

    mail($mailTo, $subject, $txt, $headers);
    header("Location: ../contact.html?mailsend");
}

?>