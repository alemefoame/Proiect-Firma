let slides = document.querySelectorAll('.home .slides-container .slide');
let index = 0;

function next() {
    slides[index].classList.remove('active');
    index = (index + 1) % slides.length;
    slides[index].classList.add('active');
}

function prev() {
    slides[index].classList.remove('active');
    index = (index - 1 + slides.length) % slides.length;
    slides[index].classList.add('active');
}

document.addEventListener('DOMContentLoaded', function () {
    const heading = document.querySelector('.about-us h2');
    const image = document.querySelector('.about-us img');
    const paragraph = document.querySelector('.about-us p');

    heading.classList.add('animate__animated', 'animate__fadeIn');
    image.classList.add('animate__animated', 'animate__zoomIn');
    paragraph.classList.add('animate__animated', 'animate__fadeInUp');
});
