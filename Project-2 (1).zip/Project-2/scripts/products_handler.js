/*
This script is used to load the products from the JSON file and generate the product elements in HTML.

The generated HTML structure for each product is the following:

<div class="box">
    <!-- Image -->
    <div class="img">
        <img src="assets/images/products/product_id.jpg" alt="Product Name">
    </div>

    <!-- Content -->
    <div class="content">
        <!-- Product Name -->
        <h3>Product Name</h3>

        <!-- Price -->
        <div class="price">Product Price LEI</div>

        <!-- Button -->
        <a href="#" class="btn">Add to Cart</a>
    </div>
</div>

 */

// Function to retrieve JSON data
function loadProducts() {
    fetch('../assets/products.json')
        .then(response => response.json())
        .then(data => {
            // Store the products in local storage
            localStorage.setItem('products', JSON.stringify(data));
            // Call function to generate product elements
            generateProductElements(data);
        })
        .catch(error => {
            console.log('Error:', error);
        });
}

// Function to add product to cart
function addToCart(productId) {
    // Retrieve the existing cart data from local storage
    var cartData = localStorage.getItem('cart');
    var cart = cartData ? JSON.parse(cartData) : [];

    // Find the product in the products array based on the productId
    var products = JSON.parse(localStorage.getItem('products'));

    var product = products.find(function (product) {
        return product.id === productId;
    });

    // Add the product to the cart or update the quantity
    if (product) {
        var existingCartItem = cart.find(function (item) {
            return item.productId === productId;
        });

        if (existingCartItem) {
            // If the product already exists in the cart, update the quantity
            existingCartItem.quantity += 1;
        } else {
            // If the product is new, add it to the cart with a quantity of 1
            cart.push({
                productId: productId,
                product: product,
                quantity: 1
            });
        }

        localStorage.setItem('cart', JSON.stringify(cart));
        console.log('Product added to cart:', product);
        alert("Produs adaugat in cos");
    }
}

// Function to generate product elements in HTML
function generateProductElements(products) {
    var boxContainer = document.querySelector('section.products .box-container');

    // Iterate over the products array
    products.forEach(function (product) {
        // Create product container element
        var productContainer = document.createElement('div');
        productContainer.classList.add('box');

        // Create image container element
        var imgContainer = document.createElement('div');
        imgContainer.classList.add('img');

        // Create image element
        var imageElement = document.createElement('img');
        imageElement.src = 'assets/images/products/product_' + product.id + '.jpg';
        imageElement.alt = product.name;
        imgContainer.appendChild(imageElement);

        // Append image container to product container
        productContainer.appendChild(imgContainer);

        // Create content element
        var contentElement = document.createElement('div');
        contentElement.classList.add('content');

        // Create name element
        var nameElement = document.createElement('h3');
        nameElement.textContent = product.name;
        contentElement.appendChild(nameElement);

        // Create price element
        var priceElement = document.createElement('div');
        priceElement.classList.add('price');
        priceElement.textContent = product.price + ' LEI';
        contentElement.appendChild(priceElement);

        // Create "Add to Cart" button
        var addToCartButton = document.createElement('button');
        addToCartButton.textContent = 'Add to Cart';
        addToCartButton.classList.add('add-to-cart-button', 'btn');
        addToCartButton.addEventListener('click', function () {
            addToCart(product.id);
        })

        contentElement.appendChild(addToCartButton);

        // Append content element to product container
        productContainer.appendChild(contentElement);

        // Add product container to box container
        boxContainer.appendChild(productContainer);
    });
}

// Call the loadProducts function when the page has loaded
window.addEventListener('load', loadProducts);
